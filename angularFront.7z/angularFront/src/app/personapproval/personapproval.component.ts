import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-personapproval',
  templateUrl: './personapproval.component.html',
  styleUrls: ['./personapproval.component.css']
})
export class PersonapprovalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

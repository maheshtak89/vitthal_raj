import { Component, OnInit } from "@angular/core";
import { User, Users } from "./../../models/app.user.model";
import { FormGroup, FormControl, Validators } from "@angular/forms";
import { UserService } from "src/services/UserService";
import { Router } from "@angular/router";
import { Response } from "@angular/http";

@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.css"]
})
export class LoginComponent implements OnInit {
  token: string;
  user: User;
  message: string;
  frmLogin: FormGroup;

  constructor(private usrServ: UserService, private router: Router) {
    this.message = "";
    this.user = new User("", "", "", 0);

    this.frmLogin = new FormGroup({
      UserName: new FormControl(
        this.user.userName,
        Validators.compose([Validators.required])
      ),
      Password: new FormControl(
        this.user.password,
        Validators.compose([Validators.required])
      )
    });
  }

  ngOnInit() {}

  signIn(): void {
    this.user = this.frmLogin.value;
    console.log(JSON.stringify(this.user));

    this.usrServ.getLoginInfo(this.user).subscribe(
      (resp: Response) => {
        if (resp.json().token) {
          sessionStorage.setItem('token', resp.json().token);
          sessionStorage.setItem('UserName', resp.json().UserName);
          sessionStorage.setItem('RoleName', resp.json().RoleName);
          this.router.navigate(['dashboard/home']);
        } else {
          this.message = resp.json().message;
        }
      },
      error => {
        console.log(`Error Occured ${error}`);
      }
    );
  }
}

import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { UserComponent } from './user/user.component';
import { HomeComponent } from './home/home.component';
import { AppGuardService } from './../services/AppGuardService';
import { ListuserComponent } from './listuser/listuser.component';

//Define Route table
const routes: Routes = [
{ path: "login", component: LoginComponent},
{ path: "dashboard",
  component: DashboardComponent, canActivate:[AppGuardService],
  children: [
    {
      path:"home",
      component: HomeComponent
    },

    {
      path:"user",
      component: UserComponent
    },

    {
      path:"listuser",
      component: ListuserComponent
    }
  ]},

{
  path: "",
  redirectTo: "login",
  pathMatch: "full"
},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-personinfo',
  templateUrl: './personinfo.component.html',
  styleUrls: ['./personinfo.component.css']
})
export class PersoninfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

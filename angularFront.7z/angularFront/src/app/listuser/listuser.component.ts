import { Component, OnInit } from '@angular/core';
import { User } from 'src/models/app.user.model';
import { FormGroup } from '@angular/forms';
import { UserService } from 'src/services/UserService';
import { Router } from '@angular/router';
import { Response } from '@angular/http';

@Component({
  selector: 'app-listuser',
  templateUrl: './listuser.component.html',
  styleUrls: ['./listuser.component.css']
})
export class ListuserComponent implements OnInit {
  user: User;
  token: string;
  users: Array<User>;
  userHeaders: Array<string>;

  constructor(private userServ: UserService, private router: Router) {
    this.user = new User('','','',0);
    this.users = new Array<User>();
    this.userHeaders = new Array<string>();
    this.token = sessionStorage.getItem('token');
  }

  ngOnInit() {

      for(let u in this.user){
          this.userHeaders.push(u);
      }

      this.userServ.getUserData(this.token).subscribe(
        (resp: Response) => {
            this.users = resp.json().data;
            console.log(JSON.stringify(this.users));
        },
        error => {
          console.log(`Error Occured ${error}`);
        }
    )
  }

}

var mongoose = require("mongoose");

var usermod = require("../app.personinfo.models/users.model");
var rolemod=require("./../app.personinfo.models/roles.model");

var RoleModel = mongoose.model("Roles");
var UserModel = mongoose.model("Users");

module.exports ={
   // Get Users function returns all users
    getUsers: function(request,response){

        UserModel.find().exec(function(err, res) {
            if (err) {
                response.statuscode = 404;
                response.send({ status: response.statuscode, error: err });
              }

              response.statuscode = 200;
              response.send({ status: response.statuscode, data: res });
        })
    },

    postUser: function(request, response){
        // find Max UserId to autoincrement
        UserModel.find().sort({userId: -1}).limit(1).exec(function(err, res) {
            var maxuserid= res[0].userId;
            if (err) {
                response.statuscode = 404;
                response.send({ status: response.statuscode, error: err });
              }
              var userId= maxuserid + 1;

                let user={
                    UserId: userId,
                    UserName: request.body.userName,
                    EmailAddress: request.body.emailAddress,
                    Password: request.body.password,
                    RoleId: request.body.roleId
                }

                //post operation
                UserModel.findOne({userName: request.body.userName},function(err, respUser){
                    if(respUser != null){
                        response.statuscode = 200;
                        response.send({ status: response.statuscode, message: "User already exist..!" });
                    } else{
                         UserModel.create(user, function(err, res){
                            if (err) {
                                response.statuscode = 404;
                                response.send({ status: response.statuscode, error: err });
                            }
                            response.statuscode = 200;
                            response.send({ status: response.statuscode, data: respUser , message: "User Information added successfully...!"});
                        });
                    }
            });
        });
    },


    updateUser: function(request, response){
        
        let user={
            UserId: request.body.userId,
            UserName: request.body.userName,
            EmailAddress: request.body.emailAddress,
            Password: request.body.password,
            RoleId: request.body.roleId
        }
        let condition= {
            UserId: request.params.id
        }

        UserModel.updateOne(condition, user, function(err, res){
            if (err) {
                response.statuscode = 404;
                response.send({ status: response.statuscode, error: err });
              }
            
              response.statuscode = 200;
              response.send({ status: response.statuscode, data: res, message: "User Information updated successfully...!" });
        });
    },


    deleteUser: function(request, response){
       
        let condition= {
            UserId: request.params.userId
        }

        UserModel.deleteOne(condition, function(err, res){
            if (err) {
                response.statuscode = 404;
                response.send({ status: response.statuscode, error: err });
              }
             
              response.statuscode = 200;
              response.send({ status: response.statuscode, data: res, message: "User Information deleted...!" });
        });
    },

    searchByUserName: function(request, response){

        UserModel.find({UserName: request.params.userName}).exec(function(err, res) {
            if (err) {
                response.statuscode = 404;
                response.send({ status: response.statuscode, error: err });
              }
              response.statuscode = 200;
              response.send({ status: response.statuscode, data: res });
        })
    }

}